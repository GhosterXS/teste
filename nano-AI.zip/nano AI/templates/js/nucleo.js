// Funções base: atalhos, escape, markdown, pedidos à API, armazenamento
'use strict';
const $=id=>document.getElementById(id),cv=$('chat-view'),empty=$('empty-state');
const copySVG='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>';
let active=null,chats=[],busy=false,attachments=[],folder='.',files=[],selected=new Set(),view='list',follow=true,autoScrollUntil=0,user='',ready=false,themeReady=false;
function esc(t){return String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function safeURL(t){try{const u=new URL(t,location.origin);return ['http:','https:'].includes(u.protocol)?u.href:'#'}catch{return '#'}}
function inline(t){return esc(t).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\[([^\]]+)\]\(([^)]+)\)/g,(_,a,b)=>`<a href="${esc(safeURL(b))}" rel="noopener noreferrer">${a}</a>`)}
function md(text){let out='',code=false,list='',paragraph=[];const flush=()=>{if(paragraph.length){out+='<p>'+inline(paragraph.join('\n')).replace(/\n/g,'<br>')+'</p>';paragraph=[]}},end=()=>{if(list){out+='</'+list+'>';list=''}};for(const line of String(text).split('\n')){if(line.startsWith('```')){flush();end();if(code){out+='</code></pre>';code=false}else{const lang=line.slice(3).trim().split(/\s/)[0];out+='<pre data-language="'+esc(lang)+'"><code>';code=true}continue}if(code){out+=esc(line)+'\n';continue}const m=line.match(/^\s*([-*]|\d+\.)\s+(.+)/);if(m){flush();const kind=/\d/.test(m[1])?'ol':'ul';if(list!==kind){end();list=kind;out+='<'+kind+'>'}out+='<li>'+inline(m[2])+'</li>';continue}end();if(/^#{1,6}\s/.test(line)){flush();out+='<h2>'+inline(line.replace(/^#{1,6}\s+/,''))+'</h2>';continue}if(!line.trim())flush();else paragraph.push(line)}flush();end();return out+(code?'</code></pre>':'')}
function toast(t){$('toast').hidden=false;$('toast').textContent=t;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,8000)}
async function api(path,options={}){const r=await fetch(path,options),d=await r.json().catch(()=>({detail:'Resposta inválida do servidor.'}));if(r.status===401){location.href='/login';throw Error('Sessão expirada.')}if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:JSON.stringify(d.detail||d));return d}
const post=(path,d)=>api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});
function storageGet(k){try{return localStorage.getItem(k)}catch{return null}}
function storageSet(k,v){try{v===null?localStorage.removeItem(k):localStorage.setItem(k,v)}catch{}}
function rememberActive(){if(user)storageSet('nano-active:'+user,active)}
function closeSidebar(){$('sidebar').classList.remove('open');$('overlay').classList.remove('active')}
function openSidebar(){$('sidebar').classList.add('open');$('overlay').classList.add('active')}
