// Seletor de modelo e botão de pensamento profundo
'use strict';
let currentModel='nano padrão',deepThinking=false,modelMap={},installed=new Set(),ollamaOnline=true,warmState={};
function closeSubmenus(){$('model-menu').classList.remove('open');$('model-trigger').classList.remove('selected');$('model-trigger').setAttribute('aria-expanded','false')}
function closePicker(){$('model-selector').classList.remove('open');$('pick-btn').setAttribute('aria-expanded','false');closeSubmenus()}
function toggleModelDropdown(){const open=$('model-selector').classList.contains('open');closePicker();if(!open){$('model-selector').classList.add('open');$('pick-btn').setAttribute('aria-expanded','true')}}
function toggleSub(){const open=$('model-menu').classList.contains('open');closeSubmenus();if(!open){$('model-menu').classList.add('open');$('model-trigger').classList.add('selected');$('model-trigger').setAttribute('aria-expanded','true')}}
$('model-trigger').onclick=e=>{e.stopPropagation();toggleSub()};
$('deep-toggle').onclick=e=>{e.stopPropagation();setDeep(!deepThinking)};
$('pick-btn').onclick=e=>{e.stopPropagation();toggleModelDropdown()};
document.addEventListener('click',e=>{if(!e.target.closest('#model-selector'))closePicker()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closePicker()});
function setDeep(on){deepThinking=!!on;storageSet('nano-deep',deepThinking?'1':'0');renderModelPill()}
function isInstalled(label){const m=modelMap[label];return !m||!ollamaOnline?null:installed.has(m)||installed.has(m+':latest')||installed.has(m.replace(/:latest$/,''))}
function pickItem(text,hint,selected,title,fn){const b=document.createElement('button');b.type='button';b.className='pick-item'+(selected?' selected':'');b.setAttribute('role','menuitemradio');b.setAttribute('aria-checked',String(selected));if(title)b.title=title;const t=document.createElement('span');t.className='pick-text';t.textContent=text;b.append(t);if(hint){const h=document.createElement('small');h.textContent=hint;b.append(h)}const c=document.createElement('span');c.className='check';c.textContent=selected?'✓':'';b.append(c);b.onclick=e=>{e.stopPropagation();fn()};return b}
function renderModelPill(){$('current-model').textContent=currentModel+(deepThinking?' · Profundo':'');$('model-trigger-value').textContent=currentModel;const t=$('deep-toggle');t.classList.toggle('on',deepThinking);t.setAttribute('aria-checked',String(deepThinking))}
function renderModelList(){const root=$('model-list');root.replaceChildren();for(const label of Object.keys(modelMap)){const ok=isInstalled(label),warm=warmState[modelMap[label]];const hint=ok===false?'não instalado':warm==='a carregar'?'a iniciar…':warm==='erro'?'erro ao iniciar':'';root.append(pickItem(label,hint,label===currentModel,modelMap[label]+(ok===false?' · instale com: ollama pull '+modelMap[label]:''),()=>{if(ok===false)toast('Este modelo não está instalado. No terminal: ollama pull '+modelMap[label]);currentModel=label;storageSet('nano-model',label);renderModelList();renderModelPill();closePicker()}))}}
