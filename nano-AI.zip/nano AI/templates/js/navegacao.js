// Scroll automático, separadores e novo chat
'use strict';
// A seta só muda de estado com margem (histerese), para não piscar ao subir devagar.
let arrowShown=false,lastTop=0,lastH=0;
function distBottom(){return cv.scrollHeight-cv.scrollTop-cv.clientHeight}
function arrow(){const d=distBottom();if(follow||d<24)arrowShown=false;else if(d>90)arrowShown=true;$('scroll-follow-btn').hidden=!arrowShown}
function scrollIfFollowing(){if(follow){autoScrollUntil=performance.now()+90;cv.scrollTop=cv.scrollHeight;lastTop=cv.scrollTop}arrow()}
cv.addEventListener('scroll',()=>{const top=cv.scrollTop,h=cv.scrollHeight,up=top<lastTop-2&&h>=lastH;lastTop=top;lastH=h;if(performance.now()<autoScrollUntil&&!up)return;const d=distBottom();if(up&&d>8)follow=false;else if(d<24)follow=true;arrow()},{passive:true});
cv.addEventListener('wheel',e=>{if(e.deltaY<0){follow=false;autoScrollUntil=0}},{passive:true});
cv.addEventListener('touchmove',()=>{follow=false;autoScrollUntil=0},{passive:true});
function toggleScrollFollow(){follow=true;arrowShown=false;autoScrollUntil=performance.now()+700;$('scroll-follow-btn').hidden=true;cv.scrollTo({top:cv.scrollHeight,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'})}
$('scroll-follow-btn').hidden=true;
function syncNavigation(){const ws=$('workspace-view').classList.contains('active');$('nav-new-chat').classList.toggle('active',!active&&!ws);$('nav-workspace').classList.toggle('active',ws)}
function switchTab(tab){$('workspace-view').classList.toggle('active',tab==='workspace');document.body.classList.toggle('ws-open',tab==='workspace');$('chat-wrap').style.display=tab==='workspace'?'none':'flex';$('input-area').style.display=tab==='workspace'?'none':'block';syncNavigation();if(tab==='workspace')refreshFiles();closeSidebar()}
function clearAttachments(){attachments.forEach(a=>a.preview&&URL.revokeObjectURL(a.preview));attachments=[];renderAttachments()}
function startNewChat(){if(busy){toast('Aguarde pela resposta em curso.');return}active=null;rememberActive();cv.replaceChildren(empty);empty.style.display='flex';$('view-title').textContent='Novo Chat';$('msg-input').value='';clearAttachments();follow=true;arrowShown=false;switchTab('chat');renderChats();arrow()}
function newChat(){startNewChat()}
