// Desenho das mensagens, blocos de código, cartões de ficheiros e botões
'use strict';
function formatSize(n){return n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':(n/1048576).toFixed(1)+' MB'}
function icon(name,dir=false){const ext=name.split('.').pop().toLowerCase(),kind=dir?'folder':/^(zip|7z|rar|gz)$/.test(ext)?'archive':/^(png|jpg|jpeg|webp|gif|svg)$/.test(ext)?'image':/^(py|html|htm|css|js|ts|cs|c|cpp|json|sh)$/.test(ext)?'code':/^(xls|xlsx|csv)$/.test(ext)?'table':ext==='pptx'?'slide':'text';const p={folder:'M3 7h7l2 3h9v11H3z',archive:'M5 2h10l4 4v16H5z M11 3v12m-2-9h4m-4 4h4m-3 5h2v4h-2z',image:'M3 3h18v18H3z M3 17l6-6 4 4 3-3 5 6 M7 7h1',code:'m8 7-5 5 5 5m8-10 5 5-5 5m-3-14-2 18',table:'M3 3h18v18H3z M3 9h18M3 15h18M9 3v18',slide:'M3 3h18v14H3z M12 17v5m-5 0 5-5 5 5',text:'M5 2h10l4 4v16H5z M8 10h8m-8 4h8m-8 4h6'};return `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.5"><path d="${p[kind]}"/></svg>`}
async function copyText(text){if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(text);return}const t=document.createElement('textarea');t.value=text;t.style.position='fixed';t.style.left='-9999px';document.body.append(t);t.select();const ok=document.execCommand('copy');t.remove();if(!ok)throw Error('O navegador não autorizou a cópia.')}
function cleanLinks(t){return String(t).replace(/\[([^\]]*)\]\((\/api\/ficheiros\/download\?[^)]+)\)/g,'')}
function blockIsHTML(language,raw){const l=String(language||'').toLowerCase();return ['html','htm','html5','xhtml'].includes(l)||(!l&&/^\s*(?:<!doctype\s+html|<(?:html|head|body|div|main|section|p|button|form)\b)/i.test(raw))}
// Barra de um bloco de código/ficheiro. Copiar e Preview ficam bloqueados até o conteúdo estar completo (ready=false).
function codeToolbar(panel,body,title,getRaw,{preview=false,downloadURL=null,state=null,ready=true,status=''}={}){
  const bar=document.createElement('div');bar.className='artifact-toolbar';
  const head=document.createElement('div');head.className='artifact-head';
  const label=document.createElement('span');label.className='artifact-title';label.textContent=title;
  const badge=document.createElement('span');badge.className='artifact-status';badge.innerHTML='<i aria-hidden="true"></i><b></b>';
  head.append(label,badge);
  const actions=document.createElement('div');actions.className='artifact-actions';
  const locked=[];
  function button(text,fn,lock=false){const b=document.createElement('button');b.type='button';b.textContent=text;b.onclick=async()=>{if(b.disabled)return;try{await fn(b)}catch(e){toast(e.message)}};actions.append(b);if(lock)locked.push(b);return b}
  button('Copiar',async b=>{await copyText(await getRaw());b.textContent='Copiado';setTimeout(()=>b.textContent='Copiar',1300)},true);
  if(downloadURL){const a=document.createElement('a');a.textContent='Download';a.href=safeURL(downloadURL);a.download=title;actions.append(a)}
  const prev=button('Preview',async()=>openPreview(await getRaw(),label.textContent),true);prev.hidden=!preview;
  if(state?.collapsed){body.hidden=true;panel.classList.add('collapsed')}
  const collapse=button(body.hidden?'Expandir':'Minimizar',()=>{body.hidden=!body.hidden;panel.classList.toggle('collapsed',body.hidden);collapse.textContent=body.hidden?'Expandir':'Minimizar';collapse.setAttribute('aria-expanded',String(!body.hidden));if(state)state.collapsed=body.hidden;arrow()});
  collapse.setAttribute('aria-expanded',String(!body.hidden));
  bar.append(head,actions);panel.insertBefore(bar,body);
  const api={
    setReady(on,text=''){panel.classList.toggle('pending',!on);for(const b of locked){b.disabled=!on;b.title=on?'':'Disponível quando o ficheiro estiver completo'}badge.hidden=on||!text;badge.querySelector('b').textContent=text},
    setTitle(t){label.textContent=t},
    setPreview(on){prev.hidden=!on}
  };
  api.setReady(ready,status);return api}
// Converte cada <pre> da resposta num painel com barra. Com openLast=true o último bloco ainda está a ser escrito.
function decorateCodeBlocks(container,states,{openLast=false}={}){
  const all=Array.from(container.querySelectorAll('pre[data-language]'));
  all.forEach((pre,index)=>{
    if(pre.parentElement?.classList.contains('artifact-body'))return;
    const language=pre.dataset.language||'',raw=pre._fullSource??pre.textContent,visible=!pre.hidden;pre.hidden=false;
    const panel=document.createElement('section');panel.className='inline-code-panel';panel.hidden=!visible;
    const body=document.createElement('div');body.className='artifact-body';pre.replaceWith(panel);body.append(pre);panel.append(body);
    if(!states.has(index))states.set(index,{collapsed:false});
    const writing=openLast&&index===all.length-1;
    codeToolbar(panel,body,language?language.toUpperCase():'Texto',()=>Promise.resolve(raw),{preview:blockIsHTML(language,raw),state:states.get(index),ready:!writing,status:'A escrever…'})})}
const TEXT_FILE=/\.(txt|md|html?|css|js|ts|json|csv|xml|ya?ml|toml|ini|cfg|sql|sh|py|c|cpp|h|cs|java|lua|php|rs|go|log)$/i;
// Painel de um ficheiro de texto guardado (HTML, TXT, código…). Copiar/Preview só ficam ativos depois de o conteúdo carregar.
function htmlPanel(root,f){
  const path=f.caminho||new URL(f.url,location.origin).searchParams.get('caminho'),name=f.nome||path?.split('/').pop()||'ficheiro.txt',isHTML=/\.html?$/i.test(name);
  const panel=document.createElement('section');panel.className='artifact-panel';
  const body=document.createElement('div');body.className='artifact-body';
  const pre=document.createElement('pre'),code=document.createElement('code');code.textContent='A carregar o ficheiro guardado…';pre.append(code);body.append(pre);panel.append(body);root.append(panel);
  let promise;const getRaw=()=>promise||(promise=api('/api/ficheiros/ler?caminho='+encodeURIComponent(path)).then(d=>d.conteudo));
  const bar=codeToolbar(panel,body,name,getRaw,{downloadURL:f.url,preview:isHTML,ready:false,status:'A carregar…'});
  getRaw().then(raw=>{code.textContent=raw;bar.setReady(true);scrollIfFollowing()}).catch(e=>{promise=null;code.textContent='Não foi possível carregar o conteúdo: '+e.message+'\nO download continua disponível.';bar.setReady(false,'Indisponível')})}
// Painel de um ficheiro que a IA ainda está a gerar (conteúdo chega aos poucos).
function pendingPanel(root,name){
  const panel=document.createElement('section');panel.className='artifact-panel';
  const body=document.createElement('div');body.className='artifact-body live-file';
  const pre=document.createElement('pre'),code=document.createElement('code');pre.append(code);body.append(pre);panel.append(body);root.append(panel);
  const p={text:'',code,pre,panel};
  p.bar=codeToolbar(panel,body,name||'ficheiro',()=>Promise.resolve(p.text),{preview:/\.html?$/i.test(name||''),ready:false,status:'A gerar…'});
  p.setName=n=>{if(!n)return;p.bar.setTitle(n);p.bar.setPreview(/\.html?$/i.test(n))};
  return p}
function liveFiles(bubble,e){
  let box=bubble._pendingBox;
  if(!box||!box.isConnected){box=document.createElement('div');box.className='pending-files';bubble._assets.append(box);bubble._pendingBox=box;bubble._pending=new Map()}
  if(e.reset){box.replaceChildren();bubble._pending.clear()}
  const status=e.total>1?'A gerar… ('+e.passo+'/'+e.total+')':'A gerar…';
  for(const f of e.ficheiros||[]){
    let p=bubble._pending.get(f.i);
    if(!p){p=pendingPanel(box,f.nome);bubble._pending.set(f.i,p)}
    p.setName(f.nome);
    if((f.desde||0)<p.text.length)p.text=p.text.slice(0,f.desde||0);
    p.text+=f.mais||'';
    const atEnd=p.pre.scrollHeight-p.pre.scrollTop-p.pre.clientHeight<30;
    p.code.textContent=p.text;if(atEnd)p.pre.scrollTop=p.pre.scrollHeight;
    p.bar.setReady(false,status)}
  for(const p of bubble._pending.values())p.bar.setReady(false,status);
  scrollIfFollowing()}
function cards(root,text,items=[]){const found=[...String(text).matchAll(/\[([^\]]*)\]\((\/api\/ficheiros\/download\?[^)]+)\)/g)].map(m=>({nome:m[1].replace(/^(Download|Descarregar)\s*/i,''),url:m[2]})),seen=new Set();for(const f of [...items,...found]){const link=f.url||f.download;if(!link)continue;const u=new URL(link,location.origin);if(u.origin!==location.origin||u.pathname!=='/api/ficheiros/download'||seen.has(u.href))continue;seen.add(u.href);if(TEXT_FILE.test(f.caminho||u.searchParams.get('caminho')||f.nome||'')){htmlPanel(root,{...f,nome:f.nome||u.searchParams.get('caminho')?.split('/').pop(),url:u.href});continue}const card=document.createElement('div');card.className='msg-file';card.innerHTML=`<div class="msg-file-top"><div class="msg-file-icon">${icon(f.nome||'ficheiro')}</div><div class="msg-file-info"><div class="msg-file-name">${esc(f.nome||'Ficheiro')}</div><div class="msg-file-meta">${f.tamanho!=null?formatSize(f.tamanho)+' · ':''}No seu workspace</div></div></div><div class="msg-file-actions"><a class="msg-file-btn" download href="${esc(u.href)}">Download</a><button class="msg-file-btn">Workspace</button></div>`;card.querySelector('button').onclick=()=>{if(f.caminho?.includes('/'))folder=f.caminho.slice(0,f.caminho.lastIndexOf('/'));switchTab('workspace')};root.append(card)}}
function openPreview(raw,name){$('preview-name').textContent=name;const policy="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; form-action 'none'; frame-src 'none'; object-src 'none'; base-uri 'none';";$('html-preview-frame').srcdoc='<!doctype html><meta http-equiv="Content-Security-Policy" content="'+policy+'">'+raw;$('html-preview').showModal()}
function closePreview(){$('html-preview').close();$('html-preview-frame').srcdoc=''}
$('html-preview').addEventListener('close',()=>$('html-preview-frame').srcdoc='');
function renderUserAttachments(root,annexes){root.replaceChildren();root.hidden=!annexes.length;for(const a of annexes){const card=document.createElement(a.url?'a':'div');card.className='user-attachment';if(a.url){card.href=safeURL(a.url);card.download=a.nome}const image=a.tipo?.startsWith('image/')||/\.(png|jpe?g|webp)$/i.test(a.nome);if(image){const img=document.createElement('img');img.alt=a.nome;img.src=a.preview||'/api/ficheiros/imagem?caminho='+encodeURIComponent(a.caminho||a.nome);img.loading='lazy';card.append(img)}const head=document.createElement('div');head.className='attachment-heading';head.innerHTML=icon(a.nome||'ficheiro');const name=document.createElement('span');name.textContent=a.nome;head.append(name);const meta=document.createElement('small');meta.textContent=(a.tamanho!=null?formatSize(a.tamanho)+' · ':'')+(a.tipo==='zip'||/\.zip$/i.test(a.nome)?'ZIP':image?'Imagem':'Ficheiro');card.append(head,meta);root.append(card)}}
function userText(text,annexes){const suffix='\n\nAnexos: '+annexes.map(a=>a.nome).join(', ');return annexes.length&&String(text).endsWith(suffix)?String(text).slice(0,-suffix.length):text}
const ICONS={copy:copySVG,edit:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>',share:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>',reload:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-2.64-6.36"/><polyline points="21 3 21 9 15 9"/></svg>',left:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"/></svg>',right:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>',send:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>',stop:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2.5" fill="currentColor"/></svg>'};
function iconButton(cls,svg,text,title,fn){const b=document.createElement('button');b.type='button';b.className=cls;b.title=title;b.ariaLabel=title;b.innerHTML=svg;if(text!==null){const s=document.createElement('span');s.textContent=text;b.append(s)}b.onclick=async e=>{e.stopPropagation();try{await fn(b)}catch(err){toast(err.message)}};return b}
function flash(b,text,back){const s=b.querySelector('span');b.classList.add('copied');if(s)s.textContent=text;clearTimeout(b.timer);b.timer=setTimeout(()=>{b.classList.remove('copied');if(s)s.textContent=back},1600)}
async function shareText(text,name){const file=new File([text],name,{type:'text/plain'});try{if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],title:name});return 'Partilhado'}}catch(e){if(e.name==='AbortError')return 'Partilhar'}const url=URL.createObjectURL(file),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);return 'Descarregado'}
function shareName(){const t=(chats.find(c=>c.id===active)?.titulo||'resposta-nano').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^\w-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,50)||'resposta-nano';return t+'.txt'}
function copyFooter(content,bubble,pending){const footer=document.createElement('div');footer.className='assistant-footer';footer.hidden=pending;const left=document.createElement('div');left.className='footer-actions';left.append(iconButton('copy-message',ICONS.copy,'Copiar','Copiar mensagem completa',async b=>{await copyText(bubble._raw||'');flash(b,'Copiado','Copiar')}),iconButton('copy-message',ICONS.share,'Partilhar','Partilhar a mensagem completa em .txt',async b=>{const r=await shareText(bubble._raw||'',shareName());if(r!=='Partilhar')flash(b,r,'Partilhar')}),iconButton('copy-message regen-btn',ICONS.reload,null,'Regenerar resposta',()=>regenerate(bubble)));const flag=document.createElement('span');flag.className='interrupted-flag';flag.textContent='Resposta interrompida';flag.hidden=true;left.append(flag);const nav=document.createElement('div');nav.className='variant-nav';nav.hidden=true;const prev=iconButton('variant-btn',ICONS.left,null,'Versão anterior',()=>switchVariant(bubble,-1)),label=document.createElement('span'),next=iconButton('variant-btn',ICONS.right,null,'Versão seguinte',()=>switchVariant(bubble,1));label.className='variant-label';nav.append(prev,label,next);footer.append(left,nav);content.append(footer);bubble._flag=flag;bubble._nav=nav;bubble._navLabel=label;bubble._prev=prev;bubble._next=next;return footer}
// Tempo total da resposta: 5s · 1min 5s · 1h 1min 5s
function fmtDur(sec){let s=Math.max(1,Math.floor(Number(sec)||0));const h=Math.floor(s/3600),m=Math.floor(s%3600/60);s%=60;return (h?h+'h ':'')+(h||m?m+'min ':'')+s+'s'}
function updateMeta(bubble,{variantes=1,ativa=0,interrompida=false,duracao=null}={}){if(bubble._time){bubble._time.hidden=duracao==null;bubble._time.textContent=duracao==null?'':'Pensou durante '+fmtDur(duracao)}bubble._variants=Math.max(1,variantes||1);bubble._active=Math.min(Math.max(0,ativa||0),bubble._variants-1);bubble._flag.hidden=!interrompida;bubble._nav.hidden=bubble._variants<2;bubble._navLabel.textContent=(bubble._active+1)+' de '+bubble._variants;bubble._prev.disabled=bubble._active<=0;bubble._next.disabled=bubble._active>=bubble._variants-1}
function renderFinal(bubble,text,items=[]){bubble._raw=String(text);bubble.classList.remove('streaming');bubble.innerHTML=md(cleanLinks(text));decorateCodeBlocks(bubble,bubble._codeState);bubble._assets.replaceChildren();cards(bubble._assets,text,items);bubble._footer.hidden=false}
function userActions(row,bubble){const box=document.createElement('div');box.className='user-actions';box.append(iconButton('user-act',ICONS.edit,null,'Editar mensagem',()=>startEdit(row,bubble)),iconButton('user-act',ICONS.copy,null,'Copiar mensagem',async b=>{await copyText(bubble._raw||'');b.classList.add('copied');b.title='Copiado';setTimeout(()=>{b.classList.remove('copied');b.title='Copiar mensagem'},1500);toast('Mensagem copiada.')}));return box}
function addMessage(text,userMessage=false,items=[],annexes=[],pending=false,meta={}){empty.style.display='none';const row=document.createElement('div');row.className='message'+(userMessage?' user-row':' ai-row');row._index=meta.index??null;const content=document.createElement('div');content.className='msg-content';const bubble=document.createElement('div');bubble.className='msg-bubble '+(userMessage?'user':'ai');bubble._row=row;let updateAttachments=()=>{};if(userMessage){const atop=document.createElement('div');atop.className='user-attachments';const line=document.createElement('div');line.className='user-line';line.append(userActions(row,bubble),bubble);content.append(atop,line);updateAttachments=list=>{row._annexes=list;renderUserAttachments(atop,list)};updateAttachments(annexes);const visible=userText(text,annexes);bubble._raw=String(visible||'');bubble.hidden=!bubble._raw.trim();bubble.innerHTML=md(visible||'')}else{bubble._raw=String(text);bubble._codeState=new Map();const time=document.createElement('div');time.className='thought-time';time.hidden=true;bubble._time=time;const assets=document.createElement('div');assets.className='response-assets';bubble._assets=assets;content.append(time,bubble,assets);bubble._footer=copyFooter(content,bubble,pending);updateMeta(bubble,meta);if(!pending)renderFinal(bubble,text,items)}row.append(content);cv.append(row);scrollIfFollowing();return {row,bubble,setAttachments:updateAttachments}}
